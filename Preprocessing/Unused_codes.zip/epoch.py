class Epoch(object):
    DURATION = 30  # seconds

    def __init__(self, timestamp, index):
        self.timestamp = timestamp
        self.index = index
